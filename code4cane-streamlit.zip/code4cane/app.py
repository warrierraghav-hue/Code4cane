"""Code4Cane - multimodal healthcare access assistant (Streamlit version)."""
import html
import json
import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import streamlit as st
import streamlit.components.v1 as components

st.set_page_config(page_title="Code4Cane", page_icon="♿", layout="centered")
TZ = ZoneInfo("Asia/Kolkata")  # change if your users are elsewhere

ss = st.session_state
ss.setdefault("meds", [])
ss.setdefault("appts", [])
ss.setdefault("step", 1)
ss.setdefault("draft", {})
ss.setdefault("big", "")
ss.setdefault("rx", "Tab Metformin 500mg 1-0-1 after food x 30 days. "
                    "Tab Amlodipine 5mg 0-0-1 at bedtime.")


# ---------------------------------------------------------------- helpers
def inject_css(fs: int, hc: bool) -> None:
    css = f"""
    <style>
    .stApp, .stApp p, .stApp li, .stApp label, .stApp span,
    .stApp div[data-testid="stMarkdownContainer"] {{font-size:{fs}px !important; line-height:1.6}}
    .stButton>button, .stDownloadButton>button, .stFormSubmitButton>button
      {{min-height:3rem; min-width:3rem; border-radius:10px}}
    *:focus-visible {{outline:4px solid #ffd447 !important; outline-offset:3px}}
    .bigcard {{font-size:{fs * 2}px; font-weight:700; padding:1.2rem; text-align:center;
               border:3px solid #0b6b5c; border-radius:14px; margin:.8rem 0}}
    @media (prefers-reduced-motion: reduce) {{* {{animation:none !important; transition:none !important}}}}
    """
    if hc:
        css += """
        .stApp {background:#000} .stApp *, .bigcard {color:#fff}
        .stButton>button, .stFormSubmitButton>button {background:#000; border:2px solid #ffd447}
        .stButton>button *, .stFormSubmitButton>button * {color:#ffd447}
        input, textarea, [data-baseweb=select] * {background:#000 !important; color:#fff !important}
        [data-testid=stSidebar] {background:#111} .bigcard {border-color:#ffd447}
        """
    st.markdown(css + "</style>", unsafe_allow_html=True)


def speak_button(text: str, label: str = "🔊 Read aloud") -> None:
    """Browser text-to-speech. Uses the device's own voices, so it works offline
    and supports Indian languages if the device has those voices installed."""
    bg, fg = ("#ffd447", "#000") if ss.get("hc") else ("#0b6b5c", "#fff")
    payload = json.dumps(text).replace("</", "<\\/")
    components.html(
        f"""<button id="b" style="min-height:48px;padding:10px 18px;font-size:18px;
        border-radius:10px;border:2px solid {bg};background:{bg};color:{fg};cursor:pointer">
        {html.escape(label)}</button>
        <script>
        document.getElementById('b').onclick = function() {{
          var s = window.speechSynthesis; s.cancel();
          var u = new SpeechSynthesisUtterance({payload}); u.rate = 0.9; s.speak(u);
        }};
        </script>""",
        height=66,
    )


def today() -> str:
    return datetime.now(TZ).date().isoformat()


def is_taken(m: dict) -> bool:
    return m.get("taken_on") == today()  # resets automatically each day


def toggle_taken(i: int) -> None:
    m = ss.meds[i]
    m["taken_on"] = None if is_taken(m) else today()


def remove_med(i: int) -> None:
    ss.meds.pop(i)


def add_med(name: str, dose: str, t) -> None:
    ss.meds.append({"name": name, "dose": dose or "as directed",
                    "time": t.strftime("%H:%M"), "taken_on": None})


# ------------------------------------------------- prescription explainer
WHEN = {"1-0-1": "morning and night", "1-1-1": "morning, afternoon and night",
        "1-0-0": "morning", "0-0-1": "night", "0-1-0": "afternoon",
        "1-1-0": "morning and afternoon"}


def explain_prescription(text: str) -> list[str]:
    out = []
    for line in re.split(r"[.;\n]+", text):
        m = re.search(r"(?:tab|cap|syp)?\.?\s*([A-Za-z][A-Za-z-]+)\s+(\d+\s*(?:mg|ml|mcg|g))",
                      line, re.I)
        if not m:
            continue
        f = re.search(r"\b([01]-[01]-[01])\b", line)
        days = re.search(r"x\s*(\d+)\s*days?", line, re.I)
        food = ("after food" if re.search(r"after food|after meals", line, re.I)
                else "before food" if re.search(r"before food|empty stomach", line, re.I) else "")
        bed = "at bedtime" if re.search(r"bedtime", line, re.I) else ""
        strength = re.sub(r"\s+", "", m.group(2))
        s = f"Take {m.group(1)} {strength}"
        if f and f.group(1) in WHEN:
            s += f" in the {WHEN[f.group(1)]}"
        s += (f" {bed}" if bed else "") + (f", {food}" if food else "")
        s += f", for {days.group(1)} days" if days else ""
        out.append(s + ".")
    return out


def ocr_image(file) -> str:
    """Optional OCR. Needs pytesseract + the tesseract-ocr system package."""
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(file)
        try:
            return pytesseract.image_to_string(img, lang="eng+tam").strip()
        except pytesseract.TesseractError:
            return pytesseract.image_to_string(img).strip()
    except Exception:
        return ""


# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("Accessibility")
    ss.fs = st.slider("Text size", 14, 32, 18)
    ss.hc = st.toggle("High contrast", value=False)
    ss.simple = st.toggle("Simple mode", value=False,
                          help="Hides extra options and shows one task at a time.")
    st.divider()
    st.caption("Your data lives only in this browser session. Download a backup to keep it.")
    st.download_button("Download my data", json.dumps(
        {"meds": ss.meds, "appts": ss.appts}, indent=2),
        file_name="code4cane-backup.json", mime="application/json")
    up = st.file_uploader("Restore backup", type="json")
    if up is not None and ss.get("restored") != up.file_id:
        try:
            data = json.load(up)
            ss.meds, ss.appts = data.get("meds", []), data.get("appts", [])
            ss.restored = up.file_id
            st.success("Backup restored.")
        except Exception:
            st.error("This file is not a valid Code4Cane backup.")

inject_css(ss.fs, ss.hc)

st.title("Code4Cane")
st.caption("Healthcare help that adapts to you. It explains information and does not "
           "replace a doctor or pharmacist.")


# ------------------------------------------------------- live reminders
@st.fragment(run_every=30)
def reminders() -> None:
    now = datetime.now(TZ)
    for m in ss.meds:
        h, mi = map(int, m["time"].split(":"))
        late = (now - now.replace(hour=h, minute=mi, second=0, microsecond=0)).total_seconds() / 60
        if 0 <= late < 90 and not is_taken(m):
            msg = f"Time to take {m['name']} – {m['dose']}"
            st.error(f"⏰ {msg}")
            speak_button(msg, "🔊 Read reminder")


reminders()

tabs = st.tabs(["Home", "Medicines", "Appointments", "Talk to clinic", "Prescription reader"])

# ------------------------------------------------------------------ home
with tabs[0]:
    st.subheader("What do you need today?")
    st.write("Pick a tab above. Each screen can be read aloud and enlarged.")
    if not ss.simple:
        st.markdown("1. Choose the task you need.\n2. Follow one step at a time.\n"
                    "3. Press **Read aloud** to hear any screen.")
    speak_button("Welcome to Code4Cane. Choose medicines, appointments, "
                 "talk to clinic, or prescription reader.")

# ----------------------------------------------------------------- meds
with tabs[1]:
    st.subheader("My medicines")
    with st.form("med_form", clear_on_submit=True):
        name = st.text_input("Medicine name", placeholder="e.g. Metformin")
        dose = st.text_input("Dose", placeholder="e.g. 1 tablet")
        t = st.time_input("Time", value=datetime.strptime("08:00", "%H:%M").time())
        if st.form_submit_button("Add medicine", type="primary"):
            if name.strip():
                add_med(name.strip(), dose.strip(), t)
                st.rerun()
            else:
                st.warning("Please type the medicine name.")
    if not ss.meds:
        st.info("No medicines yet. Add one above.")
    for i, m in enumerate(ss.meds):
        c1, c2, c3 = st.columns([5, 2, 2])
        c1.markdown(f"**{m['name']}** – {m['dose']} at {m['time']}"
                    + ("  ✅ Taken today" if is_taken(m) else ""))
        c2.button("Undo" if is_taken(m) else "I took it", key=f"t{i}",
                  on_click=toggle_taken, args=(i,))
        c3.button("Remove", key=f"d{i}", on_click=remove_med, args=(i,))
    st.caption("Reminders appear at the top of every screen while the app is open.")

# ----------------------------------------------------------- appointments
with tabs[2]:
    st.subheader("Book an appointment")
    st.caption(f"Step {ss.step} of 3")
    DEPTS = ["General doctor", "Eye doctor", "Ear, nose and throat",
             "Heart doctor", "Skin doctor", "Child doctor"]
    SLOTS = ["Morning (9–12)", "Afternoon (2–5)"]
    HELP = ["No extra help", "Sign language interpreter", "Wheelchair access",
            "Someone to read documents to me"]

    def go(n, save=None):
        if save:
            ss.draft.update({k: ss[v] for k, v in save.items()})
        ss.step = n

    def confirm():
        d = ss.draft
        ss.appts.append(f"{d['dept']} on {d['day']}, {d['slot']}. Support: {d['help']}.")
        ss.draft, ss.step = {}, 1

    if ss.step == 1:
        st.selectbox("Who do you want to see?", DEPTS, key="w_dept")
        st.button("Next", type="primary", on_click=go, args=(2, {"dept": "w_dept"}))
    elif ss.step == 2:
        st.date_input("Which day?", value=date.today() + timedelta(days=1),
                      min_value=date.today(), key="w_day")
        st.selectbox("What time?", SLOTS, key="w_slot")
        st.selectbox("Do you need help at the visit?", HELP, key="w_help")
        a, b = st.columns(2)
        a.button("Back", on_click=go, args=(1,))
        b.button("Next", type="primary", on_click=go,
                 args=(3, {"day": "w_day", "slot": "w_slot", "help": "w_help"}))
    else:
        d = ss.draft
        summary = f"{d['dept']} on {d['day']}, {d['slot']}. Support: {d['help']}."
        st.markdown(f"### Check your booking\n{summary}")
        speak_button("Check your booking. " + summary)
        a, b = st.columns(2)
        a.button("Back", on_click=go, args=(2,))
        b.button("Confirm booking", type="primary", on_click=confirm)

    st.markdown("#### My appointments")
    if not ss.appts:
        st.info("No appointments yet.")
    for i, a_text in enumerate(ss.appts):
        c1, c2 = st.columns([5, 2])
        c1.write(a_text)
        c2.button("Cancel", key=f"c{i}", on_click=lambda i=i: ss.appts.pop(i))

# ------------------------------------------------------------------ talk
with tabs[3]:
    st.subheader("Talk to the clinic")
    st.caption("Tap a card to show it in large text. Press Read aloud to speak it.")
    PHRASES = [("🤒", "I am in pain."), ("🗣️", "Please speak slowly."),
               ("✍️", "Please write it down."), ("🔁", "Please say that again."),
               ("💊", "I need my medicine."), ("🚻", "I need the restroom."),
               ("👨‍👩‍👧", "I need my caregiver."), ("❓", "I do not understand.")]
    cols = st.columns(2)
    for i, (icon, text) in enumerate(PHRASES):
        cols[i % 2].button(f"{icon}  {text}", key=f"p{i}", use_container_width=True,
                           on_click=lambda t=text: ss.update(big=t))
    custom = st.text_area("Your own message", height=80)
    if st.button("Show my message large", type="primary") and custom.strip():
        ss.big = custom.strip()
    if ss.big:
        st.markdown(f'<div class="bigcard" role="status">{html.escape(ss.big)}</div>',
                    unsafe_allow_html=True)
        speak_button(ss.big)

# ------------------------------------------------------------------ read
with tabs[4]:
    st.subheader("Prescription reader")
    st.caption("Paste text or upload a photo. The result is explained in plain words.")
    if not ss.simple:
        img = st.file_uploader("Photo of prescription or medicine strip",
                               type=["png", "jpg", "jpeg"])
        if img is not None and ss.get("ocr_id") != img.file_id:
            ss.ocr_id = img.file_id
            text = ocr_image(img)
            if text:
                ss.rx = text
                st.success("Text read from the photo. Please check it below.")
            else:
                st.warning("Could not read the photo. Please paste the text instead.")
    st.text_area("Prescription text", key="rx", height=120)
    if st.button("Explain in simple words", type="primary"):
        results = explain_prescription(ss.rx)
        if not results:
            st.warning("Could not find a medicine. Check the text, or ask your pharmacist.")
        for r in results:
            st.markdown(f"- {r}")
        if results:
            speak_button(" ".join(results), "🔊 Read all aloud")
    st.caption("Always confirm doses with your doctor or pharmacist.")
