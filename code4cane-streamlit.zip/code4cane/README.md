# Code4Cane

Multimodal healthcare access assistant for people with visual, hearing, motor or
cognitive impairments. Built with Streamlit.

**Features:** medicine reminders, 3-step appointment booking, communication cards
with text-to-speech, prescription explainer with optional OCR, adjustable text size,
high-contrast and simple modes.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Optional OCR also needs the Tesseract program installed on your computer.

## Deploy (Streamlit Community Cloud)
1. Push this folder to a public GitHub repo.
2. Go to share.streamlit.io, sign in with GitHub, click **Create app**.
3. Choose the repo, branch `main`, main file `app.py`, then **Deploy**.

`packages.txt` installs Tesseract on the server automatically.

## Privacy notes
- No database. Data stays in the browser session; users can download/restore a backup.
- Uploaded photos are processed in server memory for OCR and are not saved.
- Do not enter real patient data in a public demo.

## Limitations
Rule-based explainer, weak on handwriting; reminders run only while the app is open;
text-to-speech depends on voices installed on the user's device.
